module.exports = {
    PORT: 3000,
    DB_CONNECTION_STRING: 'mongodb://localhost:27017/wildlife-photography',
    TOKEN_SECRET: 'CF6BF2F3633265CC7F94E12EDF6B4',
    AUTH_COOKIE_NAME: 'SESSION_TOKEN',
    SALT_ROUNDS: 10
}